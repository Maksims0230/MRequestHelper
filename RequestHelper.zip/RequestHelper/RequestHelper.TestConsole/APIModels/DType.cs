﻿using System.Text.Json.Serialization;
using RequestHelper.HelperModels;

namespace RequestHelper.TestConsole.APIModels;

public sealed class DType : BaseModel<string>
{
    public DType() : base("dialogs/types")
    {
        Id = "Chat";
    }

    [JsonPropertyName("Name")] public override string Id { get; set; }
}