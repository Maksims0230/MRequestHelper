﻿using System.Text.Json.Serialization;
using RequestHelper.HelperModels;

namespace RequestHelper.TestConsole.APIModels;

public class NUser : IBaseModel<Guid>
{
    [JsonIgnore] public byte[] Picture { get; set; } = Array.Empty<byte>();

    [JsonPropertyName("login")] public string Login { get; set; } = null!;

    [JsonPropertyName("password")] public string Password { get; set; } = null!;

    [JsonPropertyName("link")] public string Link { get; set; } = null!;

    [JsonPropertyName("surname")] public string Surname { get; set; } = null!;

    [JsonPropertyName("name")] public string Name { get; set; } = null!;

    [JsonPropertyName("patronymic")] public string? Patronymic { get; set; } = null;

    [JsonPropertyName("status")] public string Status { get; set; } = null!;

    [JsonPropertyName("id")] public Guid Id { get; set; }

    [JsonIgnore] public string Path { get; set; } = "Users";
}