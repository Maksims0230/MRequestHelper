﻿using RequestHelper.Annotations;
using RequestHelper.HelperModels;

namespace RequestHelper.TestConsole.APIModels;

[RequestPath(Path = "dialogs/types")]
public class DialogType : ISomeBaseModel
{
    [RequestId] public string Name { get; set; } = "Chat";
}