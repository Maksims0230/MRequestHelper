﻿using System.Net;
using RequestHelper.Adapters.BaseModel;
using RequestHelper.Adapters.SomeBaseModel;
using RequestHelper.HelperModels;
using RequestHelper.HelperModels.Extensions;
using RequestHelper.Helpers;
using RequestHelper.Helpers.BaseModelExtensions;
using RequestHelper.Helpers.Configurations;
using RequestHelper.Helpers.SomeBaseModelExtensions;
using RequestHelper.TestConsole.APIModels;

// Role _role = new()
// {
//     Id = "Админ"
// };
//
// User _user = new()
// {
//     Id = 0,
//     Login = "Maksims023",
//     Password = "9775732908",
//     Role = _role
// };
//
// Console.WriteLine(_user.ToJson());
//
// User user = new User();
// Console.WriteLine(await user.ToModelAsync(_user.ToJson()));
//
// Console.WriteLine(user);

//
// var user1 = new User().SetValue(_user, SetValueMode.Facile);
//
// var user2 = new User().SetValue(_user, SetValueMode.Thorough);
//
// Console.WriteLine(user1 + "\r\n" + user2);
//
// Console.WriteLine(await user1.ToJsonAsync());
//
// Console.WriteLine(await new StreamReader(user2.ToJsonStreamAsync()).ReadToEndAsync());
//    
// var summary = BenchmarkRunner.Run<BenchmarkClass>();

var usrs = new List<User>()
{
    new User
    {
        Id = Guid.NewGuid(),
        Link = "hhh",
        Login = "hhh",
        Password = "hhh",
        Name = "hhh",
        Surname = "hhh",
        Patronymic = "hhh",
        Picture = { },
        Status = "0"
    },
    new User
    {
        Id = Guid.NewGuid(),
        Link = "aaa",
        Login = "aaa",
        Password = "aaa",
        Name = "aaa",
        Surname = "aaa",
        Patronymic = "aaa",
        Picture = { },
        Status = "1"
    },
};

var usrs2 = new List<User>()
{
    new User
    {
        Id = Guid.NewGuid(),
        Link = "hhh",
        Login = "hhh",
        Password = "hhh",
        Name = "hhh",
        Surname = "hhh",
        Patronymic = "hhh",
        Picture = { },
        Status = "0"
    },
    new User
    {
        Id = Guid.NewGuid(),
        Link = "aaa",
        Login = "aaa",
        Password = "aaa",
        Name = "aaa",
        Surname = "aaa",
        Patronymic = "aaa",
        Picture = { },
        Status = "1"
    },
};


var usrsAdapter = new ModelsAdapter<User>(usrs);

usrsAdapter.ValueChangingEvent += (s, e) =>
{
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("usrsAdapter changing!");
    Console.ForegroundColor = ConsoleColor.White;

    if (e.NewValue.Count is 0)
        e.Cancel = true;
};

usrsAdapter.ValueChangedEvent += (s) =>
{
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine("usrsAdapter changed!");
    Console.ForegroundColor = ConsoleColor.White;
};

usrsAdapter.SetValue(new List<User>());

Console.WriteLine("-------------------------------------------");
usrsAdapter.ForEach(Console.WriteLine);
Console.WriteLine("-----------------------");
usrs.ForEach(Console.WriteLine);
Console.WriteLine("-------------------------------------------");
usrsAdapter.RemoveAll(usr => usr.Login == "aaa");
Console.WriteLine("-------------------------------------------");
usrsAdapter.ForEach(Console.WriteLine);
Console.WriteLine("-----------------------");
usrs.ForEach(Console.WriteLine);
Console.WriteLine("-------------------------------------------");
Console.WriteLine("-------------------------------------------");
Console.WriteLine(usrsAdapter[0].ToJson());
Console.WriteLine("-------------------------------------------");
Console.WriteLine("-------------------------------------------");





var usrs3 = new List<User>()
{
    new User
    {
        Id = Guid.Parse("068b8fe1-8530-4861-815e-b60d2ac2e76e"),
        Link = "hhh",
        Login = "hhh",
        Password = "hhh",
        Name = "hhh",
        Surname = "hhh",
        Patronymic = "hhh",
        Picture = { },
        Status = "0"
    },
    new User
    {
        Id = Guid.NewGuid(),
        Link = "aaa",
        Login = "aaa",
        Password = "aaa",
        Name = "aaa",
        Surname = "aaa",
        Patronymic = "aaa",
        Picture = { },
        Status = "1"
    },
};

var usrs4 = new List<User>()
{
    new User
    {
        Id = Guid.Parse("068b8fe1-8530-4861-815e-b60d2ac2e76e"),
        Link = "hhh",
        Login = "hhh",
        Password = "hhh",
        Name = "hhh",
        Surname = "hhh",
        Patronymic = "hhh",
        Picture = { },
        Status = "0"
    },
    new User
    {
        Id = Guid.NewGuid(),
        Link = "zzz",
        Login = "zzz",
        Password = "zzz",
        Name = "zzz",
        Surname = "zzz",
        Patronymic = "zzz",
        Picture = { },
        Status = "1"
    },
};


var usrsAdapter3 = new ModelsAdapter<User>(usrs3);
var usrsAdapter4 = new ModelsAdapter<User>(usrs4);

var usrsAdapterConcat = usrsAdapter3 + usrsAdapter4;
Console.WriteLine("-------------------------------------------");
usrsAdapterConcat.ForEach(Console.WriteLine);
Console.WriteLine("-------------------------------------------");


var usrsAdapterExcept = usrsAdapter3 - usrsAdapter4;
Console.WriteLine("-------------------------------------------");
usrsAdapterExcept.ForEach(Console.WriteLine);
Console.WriteLine("-------------------------------------------");


var usrsAdapterMirrorExcept = usrsAdapter3 | usrsAdapter4;
Console.WriteLine("-------------------------------------------");
usrsAdapterMirrorExcept.ForEach(Console.WriteLine);
Console.WriteLine("-------------------------------------------");


var usrsAdapterIntersect = usrsAdapter3 & usrsAdapter4;
Console.WriteLine("-------------------------------------------");
usrsAdapterIntersect.ForEach(Console.WriteLine);
Console.WriteLine("-------------------------------------------");


return;

var configBasic = new RequestHelperConfiguration(baseApiUrl: "http://localhost:80/");
configBasic.EnableProtectedHeaders();
configBasic.SetProtectedHeader(new ProtectedHeader(DefaultProtectedHeaders.XApiKey,
    "BasicAccess"));
RequestHelper.Helpers.RequestHelper.AddConfiguration("Basic", configBasic, AddConfigurationMode.OnlyAdding);

var configConst = new RequestHelperConfiguration(baseApiUrl: "http://localhost:80/");
configConst.EnableProtectedHeaders();
configConst.SetProtectedHeader(new ProtectedHeader(DefaultProtectedHeaders.XApiKey,
    "26717058313a01f3d588eef6bcf6f8be"));
RequestHelper.Helpers.RequestHelper.AddConfiguration("Const", configConst);

if (await BaseRequests.SendRequestAsync(HttpMethod.Post, "api/auntificate") is
    {StatusCode: HttpStatusCode.Unauthorized})
{
    RequestHelper.Helpers.RequestHelper.SetConfiguration("Basic");
    var response = await BaseRequests.SendRequestAsync(HttpMethod.Post, "api/authorize");
    RequestHelper.Helpers.RequestHelper.SetConfiguration("Const");
    RequestHelper.Helpers.RequestHelper.Configuration.SetHeaderValue(new ProtectedHeader(
        DefaultProtectedHeaders.XApiKey,
        response.Text));
    Console.WriteLine("------------------------------------------------------------------------------------------------");
    Console.WriteLine("------------------------------------------------------------------------------------------------");
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine(response.Text);
    Console.ForegroundColor = ConsoleColor.White;
    Console.WriteLine("------------------------------------------------------------------------------------------------");
    Console.WriteLine("------------------------------------------------------------------------------------------------");
}


var user = new User
{
    Id = Guid.Parse("3fa85f64-5717-4562-b3fc-2c963f66afa6")
};

var users = new List<User>();

var user2 = new NUser
{
    Id = Guid.Parse("3fa85f64-5717-4562-b3fc-2c963f66afa6")
};

var users2 = new List<NUser>();

// ModelAdapter<User> userAdapter = new(user);
var userAdapter = user.ToModelAdapter();
await userAdapter.GetAsync();
Console.WriteLine(user.ToJson());
Console.WriteLine("------------------------------------");
// ModelAdapter<NUser, Guid> nUserAdapter = new(user2);
var nUserAdapter = user2.ToModelAdapter<NUser, Guid>();
var adapter = nUserAdapter.GetAsync().GetAsync().GetAdapter();
Console.WriteLine(user2.ToJson());
Console.WriteLine("------");
Console.WriteLine(adapter.GetValue().ToJson());

Console.WriteLine("------------------------------------------------------------------------------------------------");

// var usersAdapter = new ModelsAdapter<User>(users);
var usersAdapter = users.ToModelsAdapter();
await usersAdapter.GetAsync();
Console.WriteLine(users.AllToJson());
Console.WriteLine("------");
Console.WriteLine(usersAdapter.GetValue().AllToJson());
Console.WriteLine("------------------------------------");
//var usersAdapter2 = new ModelsAdapter<NUser, Guid>(users2);
var usersAdapter2 = users2.ToModelsAdapter<NUser, Guid>();  
await usersAdapter2.GetAsync();
Console.WriteLine(users2.AllToJson());
Console.WriteLine("------");
Console.WriteLine(usersAdapter2.GetValue().AllToJson());

return;

Console.WriteLine("------------------------------------------------------------------------------------------------");
Console.WriteLine("------------------------------------------------------------------------------------------------");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(nameof(ISomeBaseModel));
Console.ForegroundColor = ConsoleColor.White;
DialogType dialogType = new()
{
    Name = "Chat"
};
Console.WriteLine("------------------------------------------------------------------------------------------------");
Console.ForegroundColor = ConsoleColor.Yellow;
Console.WriteLine("Async");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("------------------------------------------------------------------------------------------------");

var result = await dialogType.GetAsync();
Console.WriteLine((int) result.StatusCode);
Console.WriteLine(result.Content);
Console.WriteLine(dialogType.ToJson());

Console.WriteLine("------------------------------------------------------------------------------------------------");

var dialogTypes = new List<DialogType>();
var resultList = await dialogTypes.GetAllAsync<DialogType>();
Console.WriteLine((int) resultList.StatusCode);
Console.WriteLine(resultList.Content);
Console.WriteLine(dialogTypes.AllToJson());

Console.WriteLine("------------------------------------------------------------------------------------------------");
Console.ForegroundColor = ConsoleColor.Yellow;
Console.WriteLine("NotAsync");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("------------------------------------------------------------------------------------------------");

result = dialogType.Get();
Console.WriteLine((int) result.StatusCode);
Console.WriteLine(result.Content);
Console.WriteLine(dialogType.ToJson());

Console.WriteLine("------------------------------------------------------------------------------------------------");

dialogTypes = new List<DialogType>();
resultList = dialogTypes.GetAll<DialogType>();
Console.WriteLine((int) resultList.StatusCode);
Console.WriteLine(resultList.Content);
Console.WriteLine(dialogTypes.AllToJson());

Console.WriteLine("------------------------------------------------------------------------------------------------");
Console.WriteLine("------------------------------------------------------------------------------------------------");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(nameof(BaseModel<string>));
Console.ForegroundColor = ConsoleColor.White;
DType dType = new()
{
    Id = "Chat"
};
Console.WriteLine("------------------------------------------------------------------------------------------------");
Console.ForegroundColor = ConsoleColor.Yellow;
Console.WriteLine("Async");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("------------------------------------------------------------------------------------------------");

result = await dType.GetAsync<DType, string>();
Console.WriteLine((int) result.StatusCode);
Console.WriteLine(result.Content);
Console.WriteLine(dialogType.ToJson());

Console.WriteLine("------------------------------------------------------------------------------------------------");

var dTypes = new List<DType>();
resultList = await dTypes.GetAllAsync<DType, string>();
Console.WriteLine((int) resultList.StatusCode);
Console.WriteLine(resultList.Content);
Console.WriteLine(dialogTypes.AllToJson());


Console.WriteLine("------------------------------------------------------------------------------------------------");
Console.ForegroundColor = ConsoleColor.Yellow;
Console.WriteLine("NotAsync");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("------------------------------------------------------------------------------------------------");

result = dType.Get<DType, string>();
Console.WriteLine((int) result.StatusCode);
Console.WriteLine(result.Content);
Console.WriteLine(dialogType.ToJson());

Console.WriteLine("------------------------------------------------------------------------------------------------");

dTypes = new List<DType>();
resultList = dTypes.GetAll<DType, string>();
Console.WriteLine((int) resultList.StatusCode);
Console.WriteLine(resultList.Content);
Console.WriteLine(dialogTypes.AllToJson());