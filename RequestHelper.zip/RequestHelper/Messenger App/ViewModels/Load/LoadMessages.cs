﻿using System.Collections.Generic;
using Messenger_App.Models.System;

namespace Messenger_App.ViewModels.Load;

public static class LoadMessages
{
    public static Dictionary<LoadStep, Message> MessageDictionary => new()
    {
        {LoadStep.CheckEthernetConnection, new("Проверка наличия подключения и доступа к интернету.")},
        {LoadStep.ApiSetConfiguration, new("Проверка установки конфигурации Api.")},
        {LoadStep.ApiKeyCheck, new("Проверка доступа к Api.")},
        {LoadStep.SetApiKey, new("Установка нового ключа доступа к Api.")},
        {LoadStep.ApiConnectionCheck, new("Проверка подключения к Api.")},
        {LoadStep.CheckSavedUser, new("Проверка сохранённых на компьютере пользователей.")},
    };
}