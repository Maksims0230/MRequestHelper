﻿using System;
using CommunityToolkit.Mvvm.ComponentModel;
using Messenger_App.Models.System;
using Messenger_App.Resources.Errors;

namespace Messenger_App.ViewModels.Load;

public partial class LoadViewModel : ObservableObject
{
    [ObservableProperty] private Notification? _notification;
    [ObservableProperty] private Message? _message;
    
    private bool CheckEthernetConnection()
    {
        try
        {
            Message = LoadMessages.MessageDictionary[LoadStep.CheckEthernetConnection];
            return true;
        }
        catch
        {
            Notification = LoadErrors.ErrorDictionary[LoadStep.CheckEthernetConnection];
            Notification.Visible = true;
            return false;
        }
    }
    
    private bool ApiSetConfiguration()
    {
        try
        {
            Message = LoadMessages.MessageDictionary[LoadStep.ApiSetConfiguration];
            return true;
        }
        catch
        {
            Notification = LoadErrors.ErrorDictionary[LoadStep.ApiSetConfiguration];
            Notification.Visible = true;
            return false;
        }
    }

    private bool ApiKeyCheck()
    {
        try
        {
            Message = LoadMessages.MessageDictionary[LoadStep.ApiKeyCheck];
            return true;
        }
        catch
        {
            Notification = LoadErrors.ErrorDictionary[LoadStep.ApiConnectionCheck];
            Notification.Visible = true;
            return false;
        }
    }

    private bool SetApiKey()
    {
        try
        {
            Message = LoadMessages.MessageDictionary[LoadStep.SetApiKey];
            return true;
        }
        catch
        {
            Notification = LoadErrors.ErrorDictionary[LoadStep.ApiConnectionCheck];
            Notification.Visible = true;
            return false;
        }
    }
    
    private bool ApiConnectionCheck()
    {
        try
        {
            Message = LoadMessages.MessageDictionary[LoadStep.ApiConnectionCheck];
            return true;
        }
        catch
        {
            Notification = LoadErrors.ErrorDictionary[LoadStep.ApiConnectionCheck];
            Notification.Visible = true;
            return false;
        }
    }

    private bool CheckSavedUser()
    {
        try
        {
            Message = LoadMessages.MessageDictionary[LoadStep.CheckSavedUser];
            return true;
        }
        catch
        {
            Notification = LoadErrors.ErrorDictionary[LoadStep.CheckSavedUser];
            Notification.Visible = true;
            return false;
        }
    }
}