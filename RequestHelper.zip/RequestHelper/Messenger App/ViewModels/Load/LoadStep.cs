﻿namespace Messenger_App.ViewModels.Load;

public enum LoadStep
{
    CheckEthernetConnection,
    ApiSetConfiguration,
    ApiKeyCheck,
    SetApiKey,
    ApiConnectionCheck,
    CheckSavedUser
}