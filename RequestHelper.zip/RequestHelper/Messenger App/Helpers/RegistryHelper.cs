﻿using System.Collections.Generic;

namespace Messenger_App.Helpers;

public class RegistryHelper
{
    public string RegistryFolder { get; set; } = null!;

    public string AppVersionFolder { get; set; } = null!;
    
    public readonly Dictionary<string, string> AppConfiguration = new()
    {
        {"ApiKey", "085542666349441633763b807bcc989e"},
        {"Login", ""},
        {"Password", ""}
    };

    public void SaveConfiguration()
    {
    }

    public void DefaultConfiguration()
    {
    }
}