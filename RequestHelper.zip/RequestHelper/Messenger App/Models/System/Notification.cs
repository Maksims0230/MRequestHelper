﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Messenger_App.Models.System;

public partial class Notification : ObservableObject
{
    [ObservableProperty] private string _content;
    [ObservableProperty] private string _title;
    [ObservableProperty] private bool _visible;
    
    public Notification(string title, string content)
    {
        _title = title;
        _content = content;
    }
}