﻿using System.Collections.Generic;
using Messenger_App.Models.System;
using Messenger_App.ViewModels.Load;

namespace Messenger_App.Resources.Errors;

public static class LoadErrors
{
    public static Dictionary<LoadStep, Notification> ErrorDictionary => new()
    {
        {LoadStep.CheckEthernetConnection, new("Ошибка.", "Отсутствует подключение к интернету.\r\nПроверьте наличие подключения или доступа к интернету.")},
        {LoadStep.ApiSetConfiguration, new("Ошибка.", "Произошла ошибка при попытке установить конфигурацию Api.")},
        {LoadStep.ApiConnectionCheck, new("Ошибка.", "Произошла ошибка при попытке связаться с Api.")},
    };
}