﻿using System.Windows;

namespace Messenger_App.Views;

public partial class LoadView : Window
{
    public LoadView()
    {
        InitializeComponent();
    }
}