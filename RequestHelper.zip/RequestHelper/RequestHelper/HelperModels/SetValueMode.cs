﻿namespace RequestHelper.HelperModels;

/// <summary>
///     Способ установки значения
/// </summary>
public enum SetValueMode
{
    /// <summary>
    ///     <para>Поверхностный метод установки значения.</para>
    ///     <remarks>
    ///         <para>
    ///             Устанавливает значения объекта только поверхностно, не заходя в подклассы, а присваивая подклассам
    ///             значение напрямую.
    ///         </para>
    ///         <para>Более быстрый.</para>
    ///     </remarks>
    /// </summary>
    Facile = 0,

    /// <summary>
    ///     <para>Глубокий метод установки значения.</para>
    ///     <remarks>
    ///         <para>Устанавливает значения объекта заходя в подклассы (не заходит в списки) и присваивая значения его полям.</para>
    ///         <para>Более медленный.</para>
    ///     </remarks>
    /// </summary>
    Thorough
}