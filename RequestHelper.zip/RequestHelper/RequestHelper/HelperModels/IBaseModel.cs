﻿#nullable enable
using RequestHelper.HelperModels.Extensions;

namespace RequestHelper.HelperModels;

public interface IBaseModel<TId> : IExtensionsMethods where TId : IComparable
{
    public TId Id { get; set; }

    [JsonIgnore] public string Path { get; set; }
}