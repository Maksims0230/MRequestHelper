﻿namespace RequestHelper.HelperModels.Extensions;

public interface IExtensionsMethods
{
    
}