﻿#nullable enable
using RequestHelper.Adapters.BaseModel;
using RequestHelper.Adapters.SomeBaseModel;

namespace RequestHelper.HelperModels.Extensions;

public static class Extensions
{
    #region Json Methos

       public static string ToJson<TObj>(this TObj model, JsonSerializerOptions? options = null)
        where TObj : IExtensionsMethods, new()
    {
        return JsonSerializer.Serialize(model, options);
    }
    
    public static string AllToJson<TCollection>(this TCollection model, JsonSerializerOptions? options = null)
        where TCollection : IEnumerable<IExtensionsMethods>
    {
        return JsonSerializer.Serialize(model, options);
    }

    public static Task<string> ToJsonAsync<TObj>(this TObj model, JsonSerializerOptions? options = null)
        where TObj : IExtensionsMethods, new()
    {
        using var stream = new MemoryStream();
        JsonSerializer.SerializeAsync(stream, model, model.GetType(), options);
        stream.Position = 0;
        using var reader = new StreamReader(stream);
        return reader.ReadToEndAsync();
    }
    
    public static Task<string> AllToJsonAsync<TCollection>(this TCollection model, JsonSerializerOptions? options = null)
        where TCollection : IEnumerable<IExtensionsMethods>, new()
    {
        using var stream = new MemoryStream();
        JsonSerializer.SerializeAsync(stream, model, model.GetType(), options);
        stream.Position = 0;
        using var reader = new StreamReader(stream);
        return reader.ReadToEndAsync();
    }

    public static MemoryStream ToJsonStreamAsync<TObj>(this TObj model, JsonSerializerOptions? options = null)
        where TObj : IExtensionsMethods, new()
    {
        var stream = new MemoryStream();
        JsonSerializer.SerializeAsync(stream, model, model.GetType(), options);
        stream.Position = 0;
        return stream;
    }
    
    public static MemoryStream AllToJsonStreamAsync<TCollection>(this TCollection model, JsonSerializerOptions? options = null)
        where TCollection : IEnumerable<IExtensionsMethods>, new()
    {
        var stream = new MemoryStream();
        JsonSerializer.SerializeAsync(stream, model, model.GetType(), options);
        stream.Position = 0;
        return stream;
    }

    public static TObj ToModel<TObj>(this TObj model, string json)
        where TObj : IExtensionsMethods, new()
    {
        if (string.IsNullOrWhiteSpace(json))
            throw new ArgumentException("Входная строка json была пустой.");
        var obj = JsonSerializer.Deserialize<TObj>(json);
        if (obj is not { } value)
            throw new ArgumentException($"Входная строка json не является объектом типа {model.GetType().Name}.");
        return model.SetValue(value);
    }
    
    public static TCollection AllToModel<TCollection>(this TCollection model, string json)
        where TCollection : IEnumerable<IExtensionsMethods>, new()
    {
        if (string.IsNullOrWhiteSpace(json))
            throw new ArgumentException("Входная строка json была пустой.");
        var obj = JsonSerializer.Deserialize<TCollection>(json);
        if (obj is not { } value)
            throw new ArgumentException($"Входная строка json не является объектом типа {model.GetType().Name}.");
        return model.AllSetValue(value);
    }

    public static async Task<TObj> ToModelAsync<TObj>(this TObj model, string json)
        where TObj : IExtensionsMethods, new()
    {
        if (string.IsNullOrWhiteSpace(json))
            throw new ArgumentException("Входная строка json была пустой.");
        await using var writer = new StreamWriter(new MemoryStream());
        await writer.WriteAsync(json);
        await writer.FlushAsync();
        writer.BaseStream.Position = 0;
        var obj = await JsonSerializer.DeserializeAsync<TObj>(writer.BaseStream);
        if (obj is not { } value)
            throw new ArgumentException($"Входная строка json не является объектом типа {model.GetType().Name}.");
        return model.SetValue(value);
    }
    
    public static async Task<TCollection> AllToModelAsync<TCollection>(this TCollection model, string json)
        where TCollection : IEnumerable<IExtensionsMethods>, new()
    {
        if (string.IsNullOrWhiteSpace(json))
            throw new ArgumentException("Входная строка json была пустой.");
        await using var writer = new StreamWriter(new MemoryStream());
        await writer.WriteAsync(json);
        await writer.FlushAsync();
        writer.BaseStream.Position = 0;
        var obj = await JsonSerializer.DeserializeAsync<TCollection>(writer.BaseStream);
        if (obj is not { } value)
            throw new ArgumentException($"Входная строка json не является объектом типа {model.GetType().Name}.");
        return model.AllSetValue(value);
    }

    public static async Task<TObj> ToModelStreamAsync<TObj>(this TObj model, MemoryStream stream)
        where TObj : IExtensionsMethods, new()
    {
        var obj = await JsonSerializer.DeserializeAsync<TObj>(stream);
        if (obj is not { } value)
            throw new ArgumentException($"Входная строка json не является объектом типа {model.GetType().Name}.");
        return model.SetValue(value);
    }
    
    public static async Task<TCollection> AllToModelStreamAsync<TCollection>(this TCollection model, MemoryStream stream)
        where TCollection : IEnumerable<IExtensionsMethods>, new()
    {
        var obj = await JsonSerializer.DeserializeAsync<TCollection>(stream);
        if (obj is not { } value)
            throw new ArgumentException($"Входная строка json не является объектом типа {model.GetType().Name}.");
        return model.AllSetValue(value);
    }

    #endregion

    #region Base Methods

    public static TObj SetValue<TObj>(this TObj model, TObj value, SetValueMode setMode = SetValueMode.Facile)
            where TObj : IExtensionsMethods
        {
            try
            {
                foreach (var fieldInfo in model.GetType()
                             .GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
                    if (setMode is SetValueMode.Thorough && fieldInfo.GetValue(value) is ISomeBaseModel childValue)
                    {
                        if (fieldInfo.GetValue(model) is null)
                            fieldInfo.SetValue(model, Activator.CreateInstance(fieldInfo.FieldType));
                        fieldInfo.GetValue(model).BaseSetValue(childValue);
                    }
                    else
                    {
                        fieldInfo.SetValue(model, fieldInfo.GetValue(value));
                    }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw new Exception(
                    $"{model.GetType().Name} = {value.GetType().Name}: Произошла ошибка при установке значений по именам переменных: {e.Message}.");
            }
    
            return model;
        }
    
        public static TCollection AllSetValue<TCollection>(this TCollection list, TCollection listValue, SetValueMode setMode = SetValueMode.Facile)
            where TCollection : IEnumerable<IExtensionsMethods>
        {
            if (list.LongCount() != listValue.LongCount())
                throw new ArgumentException("Ошибка: Размеры списков отличаются.");
            
            foreach (var item in list.Zip(listValue, (model, value) => new {model, value}))
            {
                try
                {
                    foreach (var fieldInfo in item.model.GetType()
                                 .GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
                        if (setMode is SetValueMode.Thorough && fieldInfo.GetValue(item.value) is ISomeBaseModel childValue)
                        {
                            if (fieldInfo.GetValue(item.model) is null)
                                fieldInfo.SetValue(item.model, Activator.CreateInstance(fieldInfo.FieldType));
                            fieldInfo.GetValue(item.model).BaseSetValue(childValue);
                        }
                        else
                        {
                            fieldInfo.SetValue(item.model, fieldInfo.GetValue(item.value));
                        }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw new Exception(
                        $"{item.model.GetType().Name} = {item.value.GetType().Name}: Произошла ошибка при установке значений по именам переменных: {e.Message}.");
                }
            }
            return list;
        }

    #endregion
    

    #region Local Methods

    private static void BaseSetValue<TObj>(this TObj model, TObj value) where TObj : new()
    {
        if (value is null) return;
        foreach (var fieldInfo in model!.GetType()
                     .GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
            if (fieldInfo.GetValue(model) is ISomeBaseModel childProperty)
                childProperty.BaseSetValue(fieldInfo.GetValue(value));
            else
                fieldInfo.SetValue(model, fieldInfo.GetValue(value) ?? default);
    }

    #endregion

    #region Adapter Convert Methods

    public static ModelAdapter<TObj> ToModelAdapter<TObj>(this TObj obj) where TObj : ISomeBaseModel, new()
    {
        return new ModelAdapter<TObj>(obj);
    }
    
    public static ModelAdapter<TObj, TId> ToModelAdapter<TObj, TId>(this TObj obj) where TObj : IBaseModel<TId>, new() where TId : IComparable
    {
        return new ModelAdapter<TObj, TId>(obj);
    }
    
    public static ModelsAdapter<TObj> ToModelsAdapter<TObj>(this IList<TObj> obj) where TObj : ISomeBaseModel, new()
    {
        return new ModelsAdapter<TObj>(obj);
    }
    
    public static ModelsAdapter<TObj, TId> ToModelsAdapter<TObj, TId>(this IList<TObj> obj) where TObj : IBaseModel<TId>, new() where TId : IComparable
    {
        return new ModelsAdapter<TObj, TId>(obj);
    }

    #endregion
}