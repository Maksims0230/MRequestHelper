﻿namespace RequestHelper.HelperModels;

public abstract class BaseModel<TId> : IBaseModel<TId> where TId : IComparable
{
    [JsonIgnore]
    public abstract TId Id { get; set; }

    protected BaseModel(string? path = null)
    {
        Path = path ?? $"{GetType().Name}s";
    }
    
    [JsonIgnore]
    public string Path { get; set; }
}