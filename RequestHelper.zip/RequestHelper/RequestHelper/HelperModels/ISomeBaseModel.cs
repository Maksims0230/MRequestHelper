﻿using RequestHelper.HelperModels.Extensions;

namespace RequestHelper.HelperModels;

public interface ISomeBaseModel : IExtensionsMethods
{
    
}