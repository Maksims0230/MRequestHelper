﻿using System.Diagnostics.CodeAnalysis;
using RequestHelper.HelperModels;

namespace RequestHelper.Adapters
{
    namespace SomeBaseModel
    {
        using Helpers.SomeBaseModelExtensions;
        
        public class ModelAdapter<TObj> : BaseValueChangeEvents<TObj> where TObj : ISomeBaseModel, new()
        {
            #region Exceptions

            internal readonly ArgumentNullException ObjIsNull = new(nameof(Obj),
                "Ошибка: Значение объекта для запроса было равно 'null'.");

            #endregion

            #region Local Methods

            internal static bool IsSuccessStatusCode(HttpStatusCode statusCode)
            {
                return (int) statusCode is >= 200 and <= 299;
            }

            #endregion

            #region Propreties

            [NotNull] private TObj _obj = new();

            [NotNull]
            internal TObj Obj
            {
                get => _obj;
                set
                {
                    if (_obj.Equals(value))
                        return;
                    var eventArgs = new ValueChangingEventArgs<TObj>(value);
                    OnValueChangingEvent(_obj, eventArgs);
                    if (eventArgs.Cancel)
                        return;
                    _obj = value;
                    OnValueChangedEvent(_obj);
                }
            }

            #endregion

            #region Ctors

            public ModelAdapter()
            {
                Obj = new TObj();
            }

            public ModelAdapter([NotNull] TObj obj)
            {
                Obj = obj;
            }

            #endregion

            #region Base Methods

            public ModelAdapter<TObj> SetValue([NotNull] TObj obj)
            {
                Obj = obj;
                return this;
            }

            public TObj GetValue()
            {
                return Obj;
            }

            #endregion

            #region Request Methods

            #region Async Methods

            public async Task<ModelAdapter<TObj>> GetAsync(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = await Obj.GetAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public async Task<ModelAdapter<TObj>> PostAsync(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = await Obj.PostAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public async Task<ModelAdapter<TObj>> PutAsync(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = await Obj.PutAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public async Task<ModelAdapter<TObj>> DeleteAsync(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = await Obj.DeleteAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            #endregion

            #region Static Methods

            public ModelAdapter<TObj> Get(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = Obj.Get(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public ModelAdapter<TObj> Post(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = Obj.Post(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public ModelAdapter<TObj> Put(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = Obj.Put(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public ModelAdapter<TObj> Delete(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = Obj.Delete(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            #endregion

            #endregion
        }

        public static partial class Extensions
        {
            #region Base Methods

            public static ModelAdapter<TObj> GetAdapter<TObj>(this Task<ModelAdapter<TObj>> taskModelAdapter)
                where TObj : ISomeBaseModel, new()
            {
                var modelAdapter = taskModelAdapter.GetAwaiter().GetResult();
                return modelAdapter;
            }

            public static async Task<ModelAdapter<TObj>> SetValue<TObj>(this Task<ModelAdapter<TObj>> taskModelAdapter,
                TObj obj) where TObj : ISomeBaseModel, new()
            {
                var modelAdapter = await taskModelAdapter;
                modelAdapter.SetValue(obj);
                return modelAdapter;
            }

            public static async Task<TObj> GetValue<TObj>(this Task<ModelAdapter<TObj>> taskModelAdapter)
                where TObj : ISomeBaseModel, new()
            {
                var modelAdapter = await taskModelAdapter;
                return modelAdapter.GetValue();
            }

            #endregion

            #region Request Methods

            public static async Task<ModelAdapter<TObj>> GetAsync<TObj>(this Task<ModelAdapter<TObj>> taskModelAdapter,
                string? urlPattern = null, Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
                where TObj : ISomeBaseModel, new()
            {
                var modelAdapter = await taskModelAdapter;
                if (modelAdapter.Obj is null)
                    throw modelAdapter.ObjIsNull;
                var result = await modelAdapter.Obj.GetAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (ModelAdapter<TObj>.IsSuccessStatusCode(result.StatusCode))
                    modelAdapter.OnValueChangedEvent(modelAdapter.Obj);
                return modelAdapter;
            }

            public static async Task<ModelAdapter<TObj>> PostAsync<TObj>(this Task<ModelAdapter<TObj>> taskModelAdapter,
                string? urlPattern = null, Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
                where TObj : ISomeBaseModel, new()
            {
                var modelAdapter = await taskModelAdapter;
                if (modelAdapter.Obj is null)
                    throw modelAdapter.ObjIsNull;
                var result = await modelAdapter.Obj.PostAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (ModelAdapter<TObj>.IsSuccessStatusCode(result.StatusCode))
                    modelAdapter.OnValueChangedEvent(modelAdapter.Obj);
                return modelAdapter;
            }

            public static async Task<ModelAdapter<TObj>> PutAsync<TObj>(this Task<ModelAdapter<TObj>> taskModelAdapter,
                string? urlPattern = null, Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
                where TObj : ISomeBaseModel, new()
            {
                var modelAdapter = await taskModelAdapter;
                if (modelAdapter.Obj is null)
                    throw modelAdapter.ObjIsNull;
                var result = await modelAdapter.Obj.PutAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (ModelAdapter<TObj>.IsSuccessStatusCode(result.StatusCode))
                    modelAdapter.OnValueChangedEvent(modelAdapter.Obj);
                return modelAdapter;
            }

            public static async Task<ModelAdapter<TObj>> DeleteAsync<TObj>(
                this Task<ModelAdapter<TObj>> taskModelAdapter, string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
                where TObj : ISomeBaseModel, new()
            {
                var modelAdapter = await taskModelAdapter;
                if (modelAdapter.Obj is null)
                    throw modelAdapter.ObjIsNull;
                var result = await modelAdapter.Obj.DeleteAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (ModelAdapter<TObj>.IsSuccessStatusCode(result.StatusCode))
                    modelAdapter.OnValueChangedEvent(modelAdapter.Obj);
                return modelAdapter;
            }

            #endregion
        }
    }

    namespace BaseModel
    {
        using Helpers.BaseModelExtensions;
        
        public class ModelAdapter<TObj, TId> : BaseValueChangeEvents<TObj>
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            #region Exceptions

            internal readonly ArgumentNullException ObjIsNull = new(nameof(Obj),
                "Ошибка: Значение объекта для запроса было равно 'null'.");

            #endregion

            #region Local Methods

            internal static bool IsSuccessStatusCode(HttpStatusCode statusCode)
            {
                return (int) statusCode is >= 200 and <= 299;
            }

            #endregion

            #region Propreties

            [NotNull] private TObj _obj = new();

            [NotNull]
            internal TObj Obj
            {
                get => _obj;
                set
                {
                    if (_obj.Equals(value))
                        return;
                    var eventArgs = new ValueChangingEventArgs<TObj>(value);
                    OnValueChangingEvent(_obj, eventArgs);
                    if (eventArgs.Cancel)
                        return;
                    _obj = value;
                    OnValueChangedEvent(_obj);
                }
            }

            #endregion

            #region Ctors

            public ModelAdapter()
            {
                Obj = new TObj();
            }

            public ModelAdapter([NotNull] TObj obj)
            {
                Obj = obj;
            }

            #endregion

            #region Base Methods

            public ModelAdapter<TObj, TId> SetValue([NotNull] TObj obj)
            {
                Obj = obj;
                return this;
            }

            public TObj GetValue()
            {
                return Obj;
            }

            #endregion

            #region Request Methods

            #region Async Methods

            public async Task<ModelAdapter<TObj, TId>> GetAsync(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = await Obj.GetAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public async Task<ModelAdapter<TObj, TId>> PostAsync(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = await Obj.PostAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public async Task<ModelAdapter<TObj, TId>> PutAsync(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = await Obj.PutAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public async Task<ModelAdapter<TObj, TId>> DeleteAsync(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = await Obj.DeleteAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            #endregion

            #region Static Methods

            public ModelAdapter<TObj, TId> Get(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = Obj.Get<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public ModelAdapter<TObj, TId> Post(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = Obj.Post<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public ModelAdapter<TObj, TId> Put(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = Obj.Put<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            public ModelAdapter<TObj, TId> Delete(string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw ObjIsNull;
                var result = Obj.Delete<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            #endregion

            #endregion
        }

        public static partial class Extensions
        {
            #region Base Methods

            public static ModelAdapter<TObj, TId> GetAdapter<TObj, TId>(
                this Task<ModelAdapter<TObj, TId>> taskModelAdapter)
                where TObj : IBaseModel<TId>, new() where TId : IComparable
            {
                var modelAdapter = taskModelAdapter.GetAwaiter().GetResult();
                return modelAdapter;
            }

            public static async Task<ModelAdapter<TObj, TId>> SetValue<TObj, TId>(
                this Task<ModelAdapter<TObj, TId>> taskModelAdapter,
                TObj obj) where TObj : IBaseModel<TId>, new() where TId : IComparable
            {
                var modelAdapter = await taskModelAdapter;
                modelAdapter.SetValue(obj);
                return modelAdapter;
            }

            public static async Task<TObj> GetValue<TObj, TId>(this Task<ModelAdapter<TObj, TId>> taskModelAdapter)
                where TObj : IBaseModel<TId>, new() where TId : IComparable
            {
                var modelAdapter = await taskModelAdapter;
                return modelAdapter.GetValue();
            }

            #endregion

            #region Request Methods

            public static async Task<ModelAdapter<TObj, TId>> GetAsync<TObj, TId>(
                this Task<ModelAdapter<TObj, TId>> taskModelAdapter,
                string? urlPattern = null, Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
                where TObj : IBaseModel<TId>, new() where TId : IComparable
            {
                var modelAdapter = await taskModelAdapter;
                if (modelAdapter.Obj is null)
                    throw modelAdapter.ObjIsNull;
                var result = await modelAdapter.Obj.GetAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (ModelAdapter<TObj, TId>.IsSuccessStatusCode(result.StatusCode))
                    modelAdapter.OnValueChangedEvent(modelAdapter.Obj);
                return modelAdapter;
            }

            public static async Task<ModelAdapter<TObj, TId>> PostAsync<TObj, TId>(
                this Task<ModelAdapter<TObj, TId>> taskModelAdapter,
                string? urlPattern = null, Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
                where TObj : IBaseModel<TId>, new() where TId : IComparable
            {
                var modelAdapter = await taskModelAdapter;
                if (modelAdapter.Obj is null)
                    throw modelAdapter.ObjIsNull;
                var result = await modelAdapter.Obj.PostAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (ModelAdapter<TObj, TId>.IsSuccessStatusCode(result.StatusCode))
                    modelAdapter.OnValueChangedEvent(modelAdapter.Obj);
                return modelAdapter;
            }

            public static async Task<ModelAdapter<TObj, TId>> PutAsync<TObj, TId>(
                this Task<ModelAdapter<TObj, TId>> taskModelAdapter,
                string? urlPattern = null, Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
                where TObj : IBaseModel<TId>, new() where TId : IComparable
            {
                var modelAdapter = await taskModelAdapter;
                if (modelAdapter.Obj is null)
                    throw modelAdapter.ObjIsNull;
                var result = await modelAdapter.Obj.PutAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (ModelAdapter<TObj, TId>.IsSuccessStatusCode(result.StatusCode))
                    modelAdapter.OnValueChangedEvent(modelAdapter.Obj);
                return modelAdapter;
            }

            public static async Task<ModelAdapter<TObj, TId>> DeleteAsync<TObj, TId>(
                this Task<ModelAdapter<TObj, TId>> taskModelAdapter, string? urlPattern = null,
                Action<TObj, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
                where TObj : IBaseModel<TId>, new() where TId : IComparable
            {
                var modelAdapter = await taskModelAdapter;
                if (modelAdapter.Obj is null)
                    throw modelAdapter.ObjIsNull;
                var result = await modelAdapter.Obj.DeleteAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (ModelAdapter<TObj, TId>.IsSuccessStatusCode(result.StatusCode))
                    modelAdapter.OnValueChangedEvent(modelAdapter.Obj);
                return modelAdapter;
            }

            #endregion
        }
    }
}