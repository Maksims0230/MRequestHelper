﻿using System.Collections.ObjectModel;
using RequestHelper.HelperModels;

namespace RequestHelper.Adapters
{
    namespace SomeBaseModel
    {
        using Helpers.SomeBaseModelExtensions;
        
        public class ModelsAdapter<TObj> : BaseValueChangeEvents<IList<TObj>> where TObj : ISomeBaseModel, new()
        {
            #region Exceptions

            private readonly ArgumentNullException _objIsNull = new(nameof(Obj),
                "Ошибка: Значение объекта для запроса было равно 'null'.");
            
            private readonly IndexOutOfRangeException _indexOutOfRangeObj = 
                new("Ошибка: Индекс вышел за границы списка.");

            #endregion

            #region Local Methods

            private static bool IsSuccessStatusCode(HttpStatusCode statusCode)
            {
                return (int) statusCode is >= 200 and <= 299;
            }

            #endregion

            #region Propreties
            
            private IList<TObj> _obj = new List<TObj>();

            private List<TObj> List => Obj as List<TObj> ?? new List<TObj>();

            internal IList<TObj> Obj
            {
                get => _obj;
                set
                {
                    var eventArgs = new ValueChangingEventArgs<IList<TObj>>(value);
                    OnValueChangingEvent(_obj, eventArgs);
                    if (eventArgs.Cancel)
                        return;
                    _obj = value;
                    OnValueChangedEvent(_obj);
                }
            }

            #endregion

            #region Ctors

            public ModelsAdapter()
            {
                Obj = new List<TObj>();
            }

            public ModelsAdapter(IList<TObj> obj)
            {
                Obj = obj;
            }

            private ModelsAdapter(IEnumerable<TObj> obj)
            {
                Obj = obj.ToList();
            }

            #endregion

            #region Operators

            public TObj this[int index]
            {
                get
                {
                    if ((uint) index >= (uint) Obj.Count)
                        throw _indexOutOfRangeObj;
                    return Obj[index];
                }
                set
                {
                    if ((uint) index >= (uint) Obj.Count)
                        throw _indexOutOfRangeObj;
                    Obj[index] = value;
                }
            }

            public static ModelsAdapter<TObj> operator +(ModelsAdapter<TObj> adapter1, ModelsAdapter<TObj> adapter2)
            {
                return new(adapter1.GetValue().Concat(adapter2.GetValue()));
            }

            public static ModelsAdapter<TObj> operator -(ModelsAdapter<TObj> adapter1, ModelsAdapter<TObj> adapter2)
            {
                return new(adapter1.GetValue().Except(adapter2.GetValue()));
            }

            public static ModelsAdapter<TObj> operator |(ModelsAdapter<TObj> adapter1, ModelsAdapter<TObj> adapter2)
            {
                return new(adapter1.GetValue().Except(adapter2.GetValue())
                    .Union(adapter2.GetValue().Except(adapter1.GetValue())));
            }

            public static ModelsAdapter<TObj> operator &(ModelsAdapter<TObj> adapter1, ModelsAdapter<TObj> adapter2)
            {
                return new(adapter1.GetValue().Intersect(adapter2.GetValue()));
            }

            #endregion

            #region Base Methods

            public ModelsAdapter<TObj> SetValue(IList<TObj> obj)
            {
                Obj = obj;
                return this;
            }

            public IList<TObj> GetValue()
            {
                return Obj;
            }

            #endregion

            #region Request Methods

            #region Async Methods

            public async Task<ModelsAdapter<TObj>> GetAsync(string? urlPattern = null,
                Action<IList<TObj>, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw _objIsNull;
                var result = await Obj.GetAllAsync(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            #endregion

            #region Static Methods

            public ModelsAdapter<TObj> Get(string? urlPattern = null,
                Action<IList<TObj>, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw _objIsNull;
                var result = Obj.GetAll(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            #endregion

            #endregion


            // TODO : Подумать о том какие методы лишние 
            #region List Methods

            public void AddItem(TObj obj)
            {
                Obj.Add(obj);
            }

            public void AddItemsRange(IEnumerable<TObj> obj)
            {
                List.AddRange(obj);
            }

            public ReadOnlyCollection<TObj> AsReadOnly()
            {
                return new(Obj);
            }

            public int BinarySearch(int index, int count, TObj item, IComparer<TObj>? comparer)
            {
                return List.BinarySearch(index, count, item, comparer);
            }

            public int BinarySearch(TObj item)
            {
                return List.BinarySearch(item);
            }

            public int BinarySearch(TObj item, IComparer<TObj>? comparer)
            {
                return List.BinarySearch(item, comparer);
            }

            public void Clear()
            {
                Obj.Clear();
            }

            public bool Contains(TObj obj)
            {
                return Obj.Contains(obj);
            }

            public List<TObj> FindAll(Predicate<TObj> match)
            {
                return List.FindAll(match);
            }

            public int FindIndex(int startIndex, int count, Predicate<TObj> match)
            {
                return List.FindIndex(startIndex, count, match);
            }

            public int FindIndex(Predicate<TObj> match)
            {
                return List.FindIndex(match);
            }

            public int FindIndex(int startIndex, Predicate<TObj> match)
            {
                return List.FindIndex(startIndex, match);
            }

            public TObj? FindLast(Predicate<TObj> match)
            {
                return List.FindLast(match);
            }

            public int FindLastIndex(Predicate<TObj> match)
            {
                return List.FindLastIndex(match);
            }

            public int FindLastIndex(int startIndex, Predicate<TObj> match)
            {
                return List.FindLastIndex(startIndex, match);
            }

            public int FindLastIndex(int startIndex, int count, Predicate<TObj> match)
            {
                return List.FindLastIndex(startIndex, count, match);
            }

            public void ForEach(Action<TObj> action)
            {
                List.ForEach(action);
            }

            public List<TObj> GetRange(int index, int count)
            {
                return List.GetRange(index, count);
            }

            public int IndexOf(TObj item)
            {
                return Obj.IndexOf(item);
            }

            public int IndexOf(TObj item, int index)
            {
                return List.IndexOf(item, index);
            }

            public int IndexOf(TObj item, int index, int count)
            {
                return List.IndexOf(item, index, count);
            }

            public void Insert(int index, TObj item)
            {
                Obj.Insert(index, item);
            }

            public void InsertRange(int index, IEnumerable<TObj> collection)
            {
                List.InsertRange(index, collection);
            }

            public int LastIndexOf(TObj item)
            {
                return List.LastIndexOf(item);
            }

            public int LastIndexOf(TObj item, int index)
            {
                return List.LastIndexOf(item, index);
            }

            public int LastIndexOf(TObj item, int index, int count)
            {
                return List.LastIndexOf(item, index, count);
            }

            public bool Remove(TObj item)
            {
                return Obj.Remove(item);
            }

            public int RemoveAll(Predicate<TObj> match)
            {
                return List.RemoveAll(match);
            }

            public void RemoveAt(int index)
            {
                Obj.RemoveAt(index);
            }

            public void RemoveRange(int index, int count)
            {
                List.RemoveRange(index, count);
            }

            public void Reverse()
            {
                List.Reverse();
            }

            public void Reverse(int index, int count)
            {
                List.Reverse(index, count);
            }

            public void Sort()
            {
                List.Sort();
            }

            public void Sort(IComparer<TObj>? comparer)
            {
                List.Sort(comparer);
            }

            public void Sort(int index, int count, IComparer<TObj>? comparer)
            {
                List.Sort(index, count, comparer);
            }

            public void Sort(Comparison<TObj> comparison)
            {
                List.Sort(comparison);
            }

            public TObj[] ToArray()
            {
                return Obj.ToArray();
            }

            public bool TrueForAll(Predicate<TObj> match)
            {
                return List.TrueForAll(match);
            }

            #endregion

        }

        public static partial class Extensions
        {
            #region Base Methods

            public static ModelsAdapter<TObj> GetAdapter<TObj>(this Task<ModelsAdapter<TObj>> taskModelsAdapter)
                where TObj : ISomeBaseModel, new()
            {
                var modelsAdapter = taskModelsAdapter.GetAwaiter().GetResult();
                return modelsAdapter;
            }

            public static async Task<ModelsAdapter<TObj>> SetValue<TObj>(
                this Task<ModelsAdapter<TObj>> taskModelsAdapter,
                IList<TObj> obj) where TObj : ISomeBaseModel, new()
            {
                var modelsAdapter = await taskModelsAdapter;
                modelsAdapter.SetValue(obj);
                return modelsAdapter;
            }

            public static async Task<IList<TObj>> GetValue<TObj>(this Task<ModelsAdapter<TObj>> taskModelsAdapter)
                where TObj : ISomeBaseModel, new()
            {
                var modelsAdapter = await taskModelsAdapter;
                return modelsAdapter.GetValue();
            }

            #endregion
        }
    }

    namespace BaseModel
    {
        using Helpers.BaseModelExtensions;
        
        public class ModelsAdapter<TObj, TId> : BaseValueChangeEvents<IList<TObj>>
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            #region Exceptions

            private readonly ArgumentNullException _objIsNull = new(nameof(Obj),
                "Ошибка: Значение объекта для запроса было равно 'null'.");

            private readonly IndexOutOfRangeException _indexOutOfRangeObj = 
                new("Ошибка: Индекс вышел за границы списка.");
            
            #endregion

            #region Local Methods

            private static bool IsSuccessStatusCode(HttpStatusCode statusCode)
            {
                return (int) statusCode is >= 200 and <= 299;
            }

            #endregion

            #region Propreties

            private IList<TObj> _obj = new List<TObj>();

            private List<TObj> List => Obj as List<TObj> ?? new List<TObj>();
            
            internal IList<TObj> Obj
            {
                get => _obj;
                set
                {
                    var eventArgs = new ValueChangingEventArgs<IList<TObj>>(value);
                    OnValueChangingEvent(_obj, eventArgs);
                    if (eventArgs.Cancel)
                        return;
                    _obj = value;
                    OnValueChangedEvent(_obj);
                }
            }

            #endregion

            #region Ctors

            public ModelsAdapter()
            {
                Obj = new List<TObj>();
            }

            public ModelsAdapter(IList<TObj> obj)
            {
                Obj = obj;
            }

            private ModelsAdapter(IEnumerable<TObj> obj)
            {
                Obj = obj.ToList();
            }

            #endregion

            #region Operators

            public TObj this[int index]
            {
                get
                {
                    if ((uint) index >= (uint) Obj.Count)
                        throw _indexOutOfRangeObj;
                    return Obj[index];
                }
                set
                {
                    if ((uint) index >= (uint) Obj.Count)
                        throw _indexOutOfRangeObj;
                    Obj[index] = value;
                }
            }

            public static ModelsAdapter<TObj, TId> operator +(ModelsAdapter<TObj, TId> adapter1,
                ModelsAdapter<TObj, TId> adapter2)
            {
                return new(adapter1.GetValue().Concat(adapter2.GetValue()));
            }

            public static ModelsAdapter<TObj, TId> operator -(ModelsAdapter<TObj, TId> adapter1,
                ModelsAdapter<TObj, TId> adapter2)
            {
                return new(adapter1.GetValue().Except(adapter2.GetValue()));
            }

            public static ModelsAdapter<TObj, TId> operator |(ModelsAdapter<TObj, TId> adapter1,
                ModelsAdapter<TObj, TId> adapter2)
            {
                return new(adapter1.GetValue().Except(adapter2.GetValue())
                    .Union(adapter2.GetValue().Except(adapter1.GetValue())));
            }

            public static ModelsAdapter<TObj, TId> operator &(ModelsAdapter<TObj, TId> adapter1,
                ModelsAdapter<TObj, TId> adapter2)
            {
                return new(adapter1.GetValue().Intersect(adapter2.GetValue()));
            }

            #endregion

            #region Base Methods

            public ModelsAdapter<TObj, TId> SetValue(IList<TObj> obj)
            {
                Obj = obj;
                return this;
            }

            public IList<TObj> GetValue()
            {
                return Obj;
            }

            #endregion

            #region Request Methods

            #region Async Methods

            public async Task<ModelsAdapter<TObj, TId>> GetAsync(string? urlPattern = null,
                Action<IList<TObj>, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw _objIsNull;
                var result = await Obj.GetAllAsync<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            #endregion

            #region Static Methods

            public ModelsAdapter<TObj, TId> Get(string? urlPattern = null,
                Action<IList<TObj>, HttpStatusCode, string>? actionSuccessStatusCodeFalse = null)
            {
                if (Obj is null)
                    throw _objIsNull;
                var result = Obj.GetAll<TObj, TId>(urlPattern, actionSuccessStatusCodeFalse);
                if (IsSuccessStatusCode(result.StatusCode))
                    OnValueChangedEvent(Obj);
                return this;
            }

            #endregion

            #endregion
            
             // TODO : Подумать о том какие методы лишние 
            #region List Methods

            public void AddItem(TObj obj)
            {
                Obj.Add(obj);
            }

            public void AddItemsRange(IEnumerable<TObj> obj)
            {
                List.AddRange(obj);
            }

            public ReadOnlyCollection<TObj> AsReadOnly()
            {
                return new(Obj);
            }

            public int BinarySearch(int index, int count, TObj item, IComparer<TObj>? comparer)
            {
                return List.BinarySearch(index, count, item, comparer);
            }

            public int BinarySearch(TObj item)
            {
                return List.BinarySearch(item);
            }

            public int BinarySearch(TObj item, IComparer<TObj>? comparer)
            {
                return List.BinarySearch(item, comparer);
            }

            public void Clear()
            {
                Obj.Clear();
            }

            public bool Contains(TObj obj)
            {
                return Obj.Contains(obj);
            }

            public List<TObj> FindAll(Predicate<TObj> match)
            {
                return List.FindAll(match);
            }

            public int FindIndex(int startIndex, int count, Predicate<TObj> match)
            {
                return List.FindIndex(startIndex, count, match);
            }

            public int FindIndex(Predicate<TObj> match)
            {
                return List.FindIndex(match);
            }

            public int FindIndex(int startIndex, Predicate<TObj> match)
            {
                return List.FindIndex(startIndex, match);
            }

            public TObj? FindLast(Predicate<TObj> match)
            {
                return List.FindLast(match);
            }

            public int FindLastIndex(Predicate<TObj> match)
            {
                return List.FindLastIndex(match);
            }

            public int FindLastIndex(int startIndex, Predicate<TObj> match)
            {
                return List.FindLastIndex(startIndex, match);
            }

            public int FindLastIndex(int startIndex, int count, Predicate<TObj> match)
            {
                return List.FindLastIndex(startIndex, count, match);
            }

            public void ForEach(Action<TObj> action)
            {
                List.ForEach(action);
            }

            public List<TObj> GetRange(int index, int count)
            {
                return List.GetRange(index, count);
            }

            public int IndexOf(TObj item)
            {
                return Obj.IndexOf(item);
            }

            public int IndexOf(TObj item, int index)
            {
                return List.IndexOf(item, index);
            }

            public int IndexOf(TObj item, int index, int count)
            {
                return List.IndexOf(item, index, count);
            }

            public void Insert(int index, TObj item)
            {
                Obj.Insert(index, item);
            }

            public void InsertRange(int index, IEnumerable<TObj> collection)
            {
                List.InsertRange(index, collection);
            }

            public int LastIndexOf(TObj item)
            {
                return List.LastIndexOf(item);
            }

            public int LastIndexOf(TObj item, int index)
            {
                return List.LastIndexOf(item, index);
            }

            public int LastIndexOf(TObj item, int index, int count)
            {
                return List.LastIndexOf(item, index, count);
            }

            public bool Remove(TObj item)
            {
                return Obj.Remove(item);
            }

            public int RemoveAll(Predicate<TObj> match)
            {
                return List.RemoveAll(match);
            }

            public void RemoveAt(int index)
            {
                Obj.RemoveAt(index);
            }

            public void RemoveRange(int index, int count)
            {
                List.RemoveRange(index, count);
            }

            public void Reverse()
            {
                List.Reverse();
            }

            public void Reverse(int index, int count)
            {
                List.Reverse(index, count);
            }

            public void Sort()
            {
                List.Sort();
            }

            public void Sort(IComparer<TObj>? comparer)
            {
                List.Sort(comparer);
            }

            public void Sort(int index, int count, IComparer<TObj>? comparer)
            {
                List.Sort(index, count, comparer);
            }

            public void Sort(Comparison<TObj> comparison)
            {
                List.Sort(comparison);
            }

            public TObj[] ToArray()
            {
                return Obj.ToArray();
            }

            public bool TrueForAll(Predicate<TObj> match)
            {
                return List.TrueForAll(match);
            }

            #endregion

        }

        public static partial class Extensions
        {
            #region Base Methods

            public static ModelsAdapter<TObj, TId> GetAdapter<TObj, TId>(
                this Task<ModelsAdapter<TObj, TId>> taskModelsAdapter)
                where TObj : IBaseModel<TId>, new()
                where TId : IComparable
            {
                var modelsAdapter = taskModelsAdapter.GetAwaiter().GetResult();
                return modelsAdapter;
            }

            public static async Task<ModelsAdapter<TObj, TId>> SetValue<TObj, TId>(
                this Task<ModelsAdapter<TObj, TId>> taskModelsAdapter,
                IList<TObj> obj) where TObj : IBaseModel<TId>, new()
                where TId : IComparable
            {
                var modelsAdapter = await taskModelsAdapter;
                modelsAdapter.SetValue(obj);
                return modelsAdapter;
            }

            public static async Task<IList<TObj>> GetValue<TObj, TId>(
                this Task<ModelsAdapter<TObj, TId>> taskModelsAdapter)
                where TObj : IBaseModel<TId>, new()
                where TId : IComparable
            {
                var modelsAdapter = await taskModelsAdapter;
                return modelsAdapter.GetValue();
            }

            #endregion
        }
    }
}