﻿namespace RequestHelper.Adapters;

public class ValueChangingEventArgs<TObj> : EventArgs
{
    public bool Cancel { get; set; } = false;

    public readonly TObj NewValue;

    public ValueChangingEventArgs(TObj newValue)
    {
        NewValue = newValue;
    }
}