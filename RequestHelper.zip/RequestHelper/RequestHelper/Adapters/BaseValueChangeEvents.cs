﻿namespace RequestHelper.Adapters;

public class BaseValueChangeEvents<TObj>
{
    #region Events

    public delegate void ValueChangingHandler(TObj nowValue, ValueChangingEventArgs<TObj> e);

    public delegate void ValueChangedHandler(TObj value);

    public event ValueChangedHandler? ValueChangedEvent;
    public event ValueChangingHandler? ValueChangingEvent;

    #region Events Invocators

    protected internal void OnValueChangedEvent(TObj value)
    {
        ValueChangedEvent?.Invoke(value);
    }

    protected void OnValueChangingEvent(TObj nowValue, ValueChangingEventArgs<TObj> newValue)
    {
        ValueChangingEvent?.Invoke(nowValue, newValue);
    }
    
    #endregion

    #endregion
}