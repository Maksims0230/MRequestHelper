﻿#nullable disable
using RequestHelper.Annotations;
using RequestHelper.HelperModels;
using RequestHelper.HelperModels.Extensions;

namespace RequestHelper.Helpers.SomeBaseModelExtensions
{
    public static class Extensions
    {
        #region Async Methods

        #region Object Methods

        public static async Task<(HttpStatusCode StatusCode, string Text)> PostAsync<TObj>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel, new()
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var path = GetPathValueInAttribute(obj);

            var content = new StringContent(JsonSerializer.Serialize(obj),
                RequestHelper.Configuration.RequestConfiguration.Encoding,
                RequestHelper.Configuration.RequestConfiguration.MediaType);
            var response = await RequestHelper.Configuration.Client.PostAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, path)
                    : $"{(path.Length > 0 ? $"{path}/" : path)}",
                content);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static async Task<(HttpStatusCode StatusCode, string Text)> PutAsync<TObj>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel, new()
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var path = GetPathValueInAttribute(obj);

            var id = string.Empty;
            if (urlPattern is not null)
            {
                var valueTuples = GetIdValueInAttribute(obj).ToArray();

                if (valueTuples is null || valueTuples.LongLength == 0)
                    throw RequestHelper.RequestIdAttributeIsNotSet;

                id = valueTuples switch
                {
                    {LongLength: 1} => valueTuples[0].id.ToString(),
                    {LongLength: > 1} => string.Concat(valueTuples.OrderBy(idAttribute => idAttribute.order)
                        .Select(idAttribute => idAttribute.id)),
                    _ => string.Empty
                };
            }

            var content = new StringContent(JsonSerializer.Serialize(obj),
                RequestHelper.Configuration.RequestConfiguration.Encoding,
                RequestHelper.Configuration.RequestConfiguration.MediaType);
            var response = await RequestHelper.Configuration.Client.PutAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, path, id)
                    : $"{(path.Length > 0 ? $"{path}/" : path)}",
                content);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static async Task<(HttpStatusCode StatusCode, string Text)> DeleteAsync<TObj>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel, new()
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var path = GetPathValueInAttribute(obj);
            var valueTuples = GetIdValueInAttribute(obj).ToArray();

            if (valueTuples is null || valueTuples.LongLength == 0)
                throw RequestHelper.RequestIdAttributeIsNotSet;

            var id = valueTuples switch
            {
                {LongLength: 1} => valueTuples[0].id.ToString(),
                {LongLength: > 1} => string.Concat(valueTuples.OrderBy(idAttribute => idAttribute.order)
                    .Select(idAttribute => idAttribute.id)),
                _ => string.Empty
            };

            var response = await RequestHelper.Configuration.Client.DeleteAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, path, id)
                    : $"{(path.Length > 0 ? $"{path}/" : path)}{(id?.Length > 0 ? $"{id}/" : id)}");
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static async Task<(HttpStatusCode StatusCode, string Content)> GetAsync<TObj>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel, new()
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var path = GetPathValueInAttribute(obj);
            var valueTuples = GetIdValueInAttribute(obj).ToArray();

            if (valueTuples is null || valueTuples.LongLength == 0)
                throw RequestHelper.RequestIdAttributeIsNotSet;

            var id = valueTuples switch
            {
                {LongLength: 1} => valueTuples[0].id.ToString(),
                {LongLength: > 1} => string.Concat(valueTuples.OrderBy(idAttribute => idAttribute.order)
                    .Select(idAttribute => idAttribute.id)),
                _ => string.Empty
            };

            var response = await RequestHelper.Configuration.Client.GetAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, path, id)
                    : $"{(path.Length > 0 ? $"{path}/" : path)}{(id?.Length > 0 ? $"{id}/" : id)}");
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        #endregion

        #region Collection Methods

        public static async Task<(HttpStatusCode StatusCode, string Content)> GetAllAsync<TObj>(
            this IList<TObj> obj,
            string urlPattern = null,
            Action<IList<TObj>, HttpStatusCode, string> actionSuccessStatusCodeFalse = null) where TObj : ISomeBaseModel
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (obj is null)
                throw RequestHelper.RequestListNull;

            var path = GetPathValueInAttribute(typeof(TObj));

            var response = await RequestHelper.Configuration.Client.GetAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, path)
                    : $"{(path.Length > 0 ? $"{path}/" : path)}");
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
            {
                obj.Clear();
                foreach (var model in JsonSerializer.Deserialize<IList<TObj>>(json) ?? new List<TObj>())
                    obj.Add(model);
            }
            else
            {
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);
            }

            return (response.StatusCode, json);
        }

        #endregion

        #endregion

        #region Static Methods

        #region Object Methods

        public static (HttpStatusCode StatusCode, string Content) Post<TObj>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel, new()
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var path = GetPathValueInAttribute(obj);

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Post,
                Content = new StringContent(JsonSerializer.Serialize(obj),
                    RequestHelper.Configuration.RequestConfiguration.Encoding,
                    RequestHelper.Configuration.RequestConfiguration.MediaType),
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, path)
                        : $"{(path.Length > 0 ? $"{path}/" : path)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static (HttpStatusCode StatusCode, string Content) Put<TObj>(this TObj obj, string urlPattern = null,
            Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel, new()
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var path = GetPathValueInAttribute(obj);

            var id = string.Empty;
            if (urlPattern is not null)
            {
                var valueTuples = GetIdValueInAttribute(obj).ToArray();

                if (valueTuples is null || valueTuples.LongLength == 0)
                    throw RequestHelper.RequestIdAttributeIsNotSet;

                id = valueTuples switch
                {
                    {LongLength: 1} => valueTuples[0].id.ToString(),
                    {LongLength: > 1} => string.Concat(valueTuples.OrderBy(idAttribute => idAttribute.order)
                        .Select(idAttribute => idAttribute.id)),
                    _ => string.Empty
                };
            }

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Put,
                Content = new StringContent(JsonSerializer.Serialize(obj),
                    RequestHelper.Configuration.RequestConfiguration.Encoding,
                    RequestHelper.Configuration.RequestConfiguration.MediaType),
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, path, id)
                        : $"{(path.Length > 0 ? $"{path}/" : path)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static (HttpStatusCode StatusCode, string Text) Delete<TObj>(this TObj obj, string urlPattern = null,
            Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel, new()
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var path = GetPathValueInAttribute(obj);
            var valueTuples = GetIdValueInAttribute(obj).ToArray();

            if (valueTuples is null || valueTuples.LongLength == 0)
                throw RequestHelper.RequestIdAttributeIsNotSet;

            var id = valueTuples switch
            {
                {LongLength: 1} => valueTuples[0].id.ToString(),
                {LongLength: > 1} => string.Concat(valueTuples.OrderBy(idAttribute => idAttribute.order)
                    .Select(idAttribute => idAttribute.id)),
                _ => string.Empty
            };

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Delete,
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, path, id)
                        : $"{(path.Length > 0 ? $"{path}/" : path)}{(id?.Length > 0 ? $"{id}/" : id)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static (HttpStatusCode StatusCode, string Content) Get<TObj>(this TObj obj, string urlPattern = null,
            Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel, new()
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var path = GetPathValueInAttribute(obj);
            var valueTuples = GetIdValueInAttribute(obj).ToArray();

            if (valueTuples is null || valueTuples.LongLength == 0)
                throw RequestHelper.RequestIdAttributeIsNotSet;

            var id = valueTuples switch
            {
                {LongLength: 1} => valueTuples[0].id.ToString(),
                {LongLength: > 1} => string.Concat(valueTuples.OrderBy(idAttribute => idAttribute.order)
                    .Select(idAttribute => idAttribute.id)),
                _ => string.Empty
            };

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, path, id)
                        : $"{(path.Length > 0 ? $"{path}/" : path)}{(id?.Length > 0 ? $"{id}/" : id)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json =
                RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                    response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        #endregion

        #region Collection Methods

        public static (HttpStatusCode StatusCode, string Content) GetAll<TObj>(
            this IList<TObj> obj,
            string urlPattern = null,
            Action<IList<TObj> , HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : ISomeBaseModel
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (obj is null)
                throw RequestHelper.RequestListNull;

            var path = GetPathValueInAttribute(typeof(TObj));

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, path)
                        : $"{(path.Length > 0 ? $"{path}/" : path)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json =
                RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                    response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
            {
                obj.Clear();
                foreach (var model in JsonSerializer.Deserialize<IList<TObj> >(json) ?? new List<TObj>())
                    obj.Add(model);
            }
            else
            {
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);
            }

            return (response.StatusCode, json);
        }

        #endregion

        #endregion

        #region Local Methods

        private static string GetPathValueInAttribute<TObj>(TObj obj) where TObj : IExtensionsMethods
        {
            return obj.GetType().GetCustomAttribute(typeof(RequestPathAttribute), false) is RequestPathAttribute
                pathAttribute
                ? pathAttribute.Path
                : string.Empty;
        }

        private static IEnumerable<(int order, object id)> GetIdValueInAttribute<TObj>(TObj obj)
            where TObj : IExtensionsMethods
        {
            foreach (var property in obj.GetType().GetProperties())
                if (property.GetCustomAttribute(typeof(RequestIdAttribute),
                        false) is RequestIdAttribute idAttribute)
                    yield return (idAttribute.Order,
                        obj.GetType().GetProperty(idAttribute.PropertyName)?.GetValue(obj));
        }

        private static string GetPathValueInAttribute(MemberInfo type)
        {
            return type.GetCustomAttribute(typeof(RequestPathAttribute), false) is RequestPathAttribute
                pathAttribute
                ? pathAttribute.Path
                : string.Empty;
        }

        #endregion
    }
}

namespace RequestHelper.Helpers.BaseModelExtensions
{
    public static class Extensions
    {
        #region Async Methods

        #region Object Methods

        public static async Task<(HttpStatusCode StatusCode, string Content)> PostAsync<TObj, TId>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var content = new StringContent(JsonSerializer.Serialize(obj),
                RequestHelper.Configuration.RequestConfiguration.Encoding,
                RequestHelper.Configuration.RequestConfiguration.MediaType);
            var response = await RequestHelper.Configuration.Client.PostAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, obj.Path)
                    : $"{(obj.Path.Length > 0 ? $"{obj.Path}/" : obj.Path)}", content);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static async Task<(HttpStatusCode StatusCode, string Content)> PutAsync<TObj, TId>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var content = new StringContent(JsonSerializer.Serialize(obj),
                RequestHelper.Configuration.RequestConfiguration.Encoding,
                RequestHelper.Configuration.RequestConfiguration.MediaType);
            var response = await RequestHelper.Configuration.Client.PutAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, obj.Path, obj.Id)
                    : $"{(obj.Path.Length > 0 ? $"{obj.Path}/" : obj.Path)}", content);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static async Task<(HttpStatusCode StatusCode, string Content)> DeleteAsync<TObj, TId>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var response = await RequestHelper.Configuration.Client.DeleteAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, obj.Path, obj.Id)
                    : $"{(obj.Path.Length > 0 ? $"{obj.Path}/" : obj.Path)}{((obj.Id.ToString()?.Length ?? 0) > 0 ? $"{obj.Id}/" : obj.Id)}");
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static async Task<(HttpStatusCode StatusCode, string Content)> GetAsync<TObj, TId>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            var response = await RequestHelper.Configuration.Client.GetAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, obj.Path, obj.Id)
                    : $"{(obj.Path.Length > 0 ? $"{obj.Path}/" : obj.Path)}{((obj.Id.ToString()?.Length ?? 0) > 0 ? $"{obj.Id}/" : obj.Id)}");
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        #endregion

        #region Collection Methods

        public static async Task<(HttpStatusCode StatusCode, string Content)> GetAllAsync<TObj, TId>(
            this IList<TObj> obj,
            string urlPattern = null,
            Action<IList<TObj> , HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
                where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (obj is null)
                throw RequestHelper.RequestListNull;

            var path = new TObj().Path;

            var response = await RequestHelper.Configuration.Client.GetAsync(
                urlPattern is not null
                    ? string.Format(urlPattern, path)
                    : $"{(path.Length > 0 ? $"{path}/" : path)}");
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
            {
                obj.Clear();
                foreach (var model in JsonSerializer.Deserialize<IList<TObj> >(json) ?? new List<TObj>())
                    obj.Add(model);
            }
            else
            {
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);
            }

            return (response.StatusCode, json);
        }

        #endregion

        #endregion

        #region Static Methods

        #region Object Methods

        public static (HttpStatusCode StatusCode, string Content) Post<TObj, TId>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Post,
                Content = new StringContent(JsonSerializer.Serialize(obj),
                    RequestHelper.Configuration.RequestConfiguration.Encoding,
                    RequestHelper.Configuration.RequestConfiguration.MediaType),
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, obj.Path)
                        : $"{(obj.Path.Length > 0 ? $"{obj.Path}/" : obj.Path)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static (HttpStatusCode StatusCode, string Content) Put<TObj, TId>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Put,
                Content = new StringContent(JsonSerializer.Serialize(obj),
                    RequestHelper.Configuration.RequestConfiguration.Encoding,
                    RequestHelper.Configuration.RequestConfiguration.MediaType),
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, obj.Path, obj.Id)
                        : $"{(obj.Path.Length > 0 ? $"{obj.Path}/" : obj.Path)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static (HttpStatusCode StatusCode, string Text) Delete<TObj, TId>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Delete,
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, obj.Path, obj.Id)
                        : $"{(obj.Path.Length > 0 ? $"{obj.Path}/" : obj.Path)}{(obj.Id?.ToString()?.Length > 0 ? $"{obj.Id}/" : obj.Id)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        public static (HttpStatusCode StatusCode, string Content) Get<TObj, TId>(this TObj obj,
            string urlPattern = null, Action<TObj, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
            where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, obj.Path, obj.Id)
                        : $"{(obj.Path.Length > 0 ? $"{obj.Path}/" : obj.Path)}{(obj.Id?.ToString()?.Length > 0 ? $"{obj.Id}/" : obj.Id)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json =
                RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                    response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
                obj.ToModel(json);
            else
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);

            return (response.StatusCode, json);
        }

        #endregion

        #region Collection Methods

        public static (HttpStatusCode StatusCode, string Content) GetAll<TObj, TId>(
            this IList<TObj> obj,
            string urlPattern = null,
            Action<IList<TObj>, HttpStatusCode, string> actionSuccessStatusCodeFalse = null)
                where TObj : IBaseModel<TId>, new() where TId : IComparable
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (obj is null)
                throw RequestHelper.RequestListNull;

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            var path = new TObj().Path;

            using var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress,
                    urlPattern is not null
                        ? string.Format(urlPattern, path)
                        : $"{(path.Length > 0 ? $"{path}/" : path)}")
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json =
                RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                    response.Content.ReadAsByteArray());

            if (response.IsSuccessStatusCode && json is {Length: > 0})
            {
                obj.Clear();
                foreach (var model in JsonSerializer.Deserialize<IList<TObj>>(json) ?? new List<TObj>())
                    obj.Add(model);
            }
            else
            {
                actionSuccessStatusCodeFalse?.Invoke(obj, response.StatusCode, json);
            }

            return (response.StatusCode, json);
        }

        #endregion

        #endregion
    }
}