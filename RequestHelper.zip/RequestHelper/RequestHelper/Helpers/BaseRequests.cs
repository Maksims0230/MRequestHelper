﻿namespace RequestHelper.Helpers;

public static class BaseRequests
    {
        public static async Task<(HttpStatusCode StatusCode, string Text)> SendRequestAsync(HttpMethod method,
            string suffixUrl, string content = "")
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = method,
                Content = new StringContent(content,
                    RequestHelper.Configuration.RequestConfiguration.Encoding,
                    RequestHelper.Configuration.RequestConfiguration.MediaType),
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress, suffixUrl)
            };

            var response = await RequestHelper.Configuration.Client.SendAsync(request);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                await response.Content.ReadAsByteArrayAsync());

            return (response.StatusCode, json);
        }

        public static (HttpStatusCode StatusCode, string Text) SendRequest(HttpMethod method,
            string suffixUrl, string content = "")
        {
            if (!RequestHelper.IsConfigured)
                throw RequestHelper.IsConfiguredFalse;

            if (RequestHelper.Configuration.Client.BaseAddress is null)
                throw RequestHelper.HttpClientBaseAddressIsNull;

            using var request = new HttpRequestMessage
            {
                Method = method,
                Content = new StringContent(content,
                    RequestHelper.Configuration.RequestConfiguration.Encoding,
                    RequestHelper.Configuration.RequestConfiguration.MediaType),
                RequestUri = new Uri(RequestHelper.Configuration.Client.BaseAddress, suffixUrl)
            };

            var response = RequestHelper.Configuration.Client.Send(request);
            var json = RequestHelper.Configuration.RequestConfiguration.Encoding.GetString(
                response.Content.ReadAsByteArray());

            return (response.StatusCode, json);
        }
    }