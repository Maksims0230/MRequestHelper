﻿using System.ComponentModel;

namespace RequestHelper.Helpers.Configurations;

/// <summary>
/// Заголовки api key по умолчанию.
/// </summary>
public enum DefaultProtectedHeaders
{
    /// <summary>
    ///     Значение: ApiKey.
    /// </summary>
    [Description("ApiKey")] ApiKey,

    /// <summary>
    ///     Значение: x-api-key.
    /// </summary>
    [Description("x-api-key")] XApiKey
}