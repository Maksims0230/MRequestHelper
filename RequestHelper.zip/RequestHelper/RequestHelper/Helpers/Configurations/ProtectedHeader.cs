﻿using System.ComponentModel;

namespace RequestHelper.Helpers.Configurations;

/// <summary>
/// Конфигурация заголовка api key.
/// </summary>
public class ProtectedHeader
{
    #region Methods

    /// <summary>
    /// Получение значения заголовка aip key из значения по умолчанию.
    /// </summary>
    /// <param name="value">Значение перечисления.</param>
    /// <returns>Значение заголовка.</returns>
    private static string GetDescription(Enum value)
    {
        var type = value.GetType();
        var name = Enum.GetName(type, value);
        if (name is null) return string.Empty;
        var field = type.GetField(name);
        if (field is null) return string.Empty;
        return Attribute.GetCustomAttribute(field,
            typeof(DescriptionAttribute)) is not DescriptionAttribute attr
            ? string.Empty
            : attr.Description;
    }

    #endregion

    #region Exceptions

    /// <summary>
    /// Ошибка значения заголовка.
    /// </summary>
    private readonly ArgumentException _protectedHeaderValueException =
        new("Ошибка: Значение заголовка не может быть равным 'null'.");

    /// <summary>
    /// Ошибка типа данных заголовка.
    /// </summary>
    private readonly ArgumentException _protectedHeaderValueTypeException =
        new("Ошибка: Тип данных заголовка может быть только 'IEnumerable<string>' или 'string'.");

    #endregion

    #region Ctors

    /// <summary>
    /// Конструктор конфигурации заголовка api key.
    /// </summary>
    /// <param name="headerName">Имя заголовка.</param>
    /// <param name="value">Значение заголовка.</param>
    /// <exception cref="ArgumentException">Ошибки: Ошибка значения заголовка; Ошибка типа данных заголовка.</exception>
    public ProtectedHeader(string headerName, object value)
    {
        if (value is not IEnumerable<string> and not string)
            throw _protectedHeaderValueTypeException;

        if (!string.IsNullOrWhiteSpace(headerName))
            ProtectedHeaderName = headerName;
        ProtectedHeaderValue = value ?? throw _protectedHeaderValueException;
    }

    /// <summary>
    /// Конструктор конфигурации заголовка api key.
    /// </summary>
    /// <param name="headerName">Заголовок по умолчанию.</param>
    /// <param name="value">Значение заголовка.</param>
    /// <exception cref="ArgumentException">Ошибки: Ошибка значения заголовка; Ошибка типа данных заголовка.</exception>
    public ProtectedHeader(DefaultProtectedHeaders headerName = DefaultProtectedHeaders.ApiKey,
        object? value = default)
    {
        if (value is null) throw _protectedHeaderValueException;
        ProtectedHeaderName = GetDescription(headerName);
        ProtectedHeaderValue = value ?? throw _protectedHeaderValueException;
    }

    #endregion


    #region Propreties

    /// <summary>
    /// Имя заголовка api key. 
    /// </summary>
    internal string ProtectedHeaderName { get; init; } = "ApiKey";
    
    /// <summary>
    /// Значение заголовка api key. 
    /// </summary>
    internal object ProtectedHeaderValue { get; init; }

    #endregion
}