﻿using System.Text;

namespace RequestHelper.Helpers.Configurations;

/// <summary>
///     Конфигурация запросов.
/// </summary>
public class RequestConfiguration
{
    /// <summary>
    ///     Тип кодировки.
    /// </summary>
    internal readonly Encoding Encoding;

    /// <summary>
    ///     Тип медиа данных.
    /// </summary>
    internal readonly string MediaType;

    /// <summary>
    ///     Конструктор конфигурации запросов.
    /// </summary>
    /// <param name="encoding">
    ///     Тип кодировки.
    ///     <para>
    ///         По умолчанию:
    ///         <code>Encoding.UTF8</code>
    ///     </para>
    /// </param>
    /// <param name="mediaType">Тип медиа данных.</param>
    public RequestConfiguration(Encoding? encoding = null, string mediaType = "application/json")
    {
        Encoding = encoding ?? Encoding.UTF8;
        MediaType = mediaType;
    }
}