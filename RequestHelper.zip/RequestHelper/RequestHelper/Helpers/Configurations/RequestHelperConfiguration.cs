﻿#nullable disable

namespace RequestHelper.Helpers.Configurations;

/// <summary>
///     Конфигурация помощника запросов.
/// </summary>
public class RequestHelperConfiguration
{
    #region Propreties

    /// <summary>
    ///     Клиент для общения с API.
    /// </summary>
    internal readonly HttpClient Client;

    /// <summary>
    ///     Конфигурация запросов.
    /// </summary>
    internal readonly RequestConfiguration RequestConfiguration;

    /// <summary>
    ///     Состояние использования api key.
    ///     <value>False.</value>
    /// </summary>
    private bool IsEnabledProtectedHeader { get; set; }

    /// <summary>
    ///     Заголовки для api key.
    /// </summary>
    private ProtectedHeader[] ProtectedHeaders { get; set; } = null!;

    #endregion

    #region Ctors

    /// <summary>
    ///     Конструктор конфигурации помощника запросов.
    /// </summary>
    /// <param name="requestConfiguration">
    ///     <para>
    ///         Конфигурация запросов.
    ///     </para>
    ///     По умолчанию:
    ///     <code>
    /// new RequestConfiguration(Encoding.UTF8, "application/json");
    /// </code>
    /// </param>
    /// <param name="baseApiUrl">
    ///     <para>
    ///         Путь использующийся как основа.
    ///     </para>
    ///     Пример:
    ///     <code>
    /// "http://localhost/"
    /// "https://localhost:7071/api/"
    /// </code>
    /// </param>
    /// <param name="disableSsl">
    ///     Отключение проверки сертификата SSL.
    /// </param>
    public RequestHelperConfiguration(RequestConfiguration requestConfiguration = null!,
        string baseApiUrl = "", bool disableSsl = false)
    {
        if (string.IsNullOrWhiteSpace(baseApiUrl))
            return;

        if (!disableSsl)
        {
            Client = new HttpClient {BaseAddress = new Uri(baseApiUrl, UriKind.Absolute)};
        }
        else
        {
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback =
                    HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
            };
            Client = new HttpClient(handler) {BaseAddress = new Uri(baseApiUrl, UriKind.Absolute)};
        }

        RequestConfiguration = requestConfiguration ?? new RequestConfiguration();
    }

    /// <summary>
    ///     Конструктор конфигурации помощника запросов.
    /// </summary>
    /// <param name="client">Клиент для общения с API.</param>
    /// <param name="requestConfiguration">
    ///     <para>
    ///         Конфигурация запросов.
    ///     </para>
    ///     По умолчанию:
    ///     <code>
    /// new RequestConfiguration(Encoding.UTF8, "application/json");
    /// </code>
    /// </param>
    public RequestHelperConfiguration(HttpClient client, RequestConfiguration requestConfiguration = null!)
    {
        Client = client;
        RequestConfiguration = requestConfiguration ?? new RequestConfiguration();
    }

    #endregion

    #region Methods

    /// <summary>
    ///     Включение (выключение) использования api key заголовка.
    /// </summary>
    /// <param name="status">Статус Вкл/Выкл.</param>
    public void EnableProtectedHeaders(bool status = true)
    {
        if (IsEnabledProtectedHeader && status)
            return;

        IsEnabledProtectedHeader = status;
        if (ProtectedHeaders?.LongLength <= 0) return;
        if (IsEnabledProtectedHeader)
            SetProtectedHeaders();
        else
            ResetClientHeaders();
    }

    /// <summary>
    ///     Установка имени и значения заголовка api key.
    /// </summary>
    /// <param name="protectedHeader">Конфигурация заголовка api key.</param>
    /// <remarks>
    ///     <para>При использовании все предыдущие установленные заголовки удаляются.</para>
    ///     Если использование api key включено, то заголовки сразу же устанавливаются,
    ///     если нет - устанавливаются при включении api key.
    /// </remarks>
    public void SetProtectedHeader(ProtectedHeader protectedHeader)
    {
        ResetClientHeaders();
        ProtectedHeaders = new[] {protectedHeader};
        if (IsEnabledProtectedHeader)
            SetProtectedHeaders();
    }

    /// <summary>
    ///     Установка нескольких имён и значений заголовка api key.
    /// </summary>
    /// <param name="protectedHeaders">Конфигурация заголовка api key.</param>
    /// <exception cref="ArgumentException">Ошибка: Отсутствие элементов в массиве.</exception>
    /// <remarks>
    ///     <para>При использовании все предыдущие установленные заголовки удаляются.</para>
    ///     Если использование api key включено, то заголовки сразу же устанавливаются,
    ///     если нет - устанавливаются при включении api key.
    /// </remarks>
    public void SetProtectedHeaders(ProtectedHeader[] protectedHeaders)
    {
        if (protectedHeaders is null or not {LongLength: > 0})
            throw _protectedHeadersArgumentException;

        if (protectedHeaders.Any(protectedHeader => protectedHeader is not {ProtectedHeaderValue: not null}))
            throw _protectedHeaderArgumentException;

        ResetClientHeaders();
        ProtectedHeaders = protectedHeaders;
        if (IsEnabledProtectedHeader)
            SetProtectedHeaders();
    }

    /// <summary>
    ///     Установка нового значения для заголовка.
    /// </summary>
    /// <param name="protectedHeader">Новая конфигурация заголовка api key.</param>
    /// <returns>Успешное/неуспешное изменение.</returns>
    public bool SetHeaderValue(ProtectedHeader protectedHeader = null!)
    {
        if (protectedHeader is null)
            return false;

        if (!ProtectedHeaders.Any(header => header.ProtectedHeaderName.Equals(protectedHeader.ProtectedHeaderName)))
            return false;

        Client.DefaultRequestHeaders.Remove(protectedHeader.ProtectedHeaderName);
        {
            if (protectedHeader.ProtectedHeaderValue is IEnumerable<string> protectedHeaderValue)
                Client.DefaultRequestHeaders.Add(protectedHeader.ProtectedHeaderName, protectedHeaderValue);
        }
        {
            if (protectedHeader.ProtectedHeaderValue is string protectedHeaderValue)
                Client.DefaultRequestHeaders.Add(protectedHeader.ProtectedHeaderName, protectedHeaderValue);
        }
        return true;
    }

    #endregion

    #region Local Methods

    /// <summary>
    ///     Сброс всех установленных api key заголовков.
    /// </summary>
    private void ResetClientHeaders()
    {
        Client.DefaultRequestHeaders.Clear();
        foreach (var defaultRequestHeader in new HttpClient().DefaultRequestHeaders)
            Client.DefaultRequestHeaders.Add(defaultRequestHeader.Key, defaultRequestHeader.Value);
    }

    /// <summary>
    ///     Установка всех заданных api key заголовков.
    /// </summary>
    private void SetProtectedHeaders()
    {
        if (!(ProtectedHeaders?.Any() ?? false))
            return;
        foreach (var protectedHeader in ProtectedHeaders)
            switch (protectedHeader.ProtectedHeaderValue)
            {
                case IEnumerable<string> protectedHeaderIEnumerableValue:
                    Client.DefaultRequestHeaders.Add(protectedHeader.ProtectedHeaderName,
                        protectedHeaderIEnumerableValue);
                    break;
                case string protectedHeaderStringValue:
                    Client.DefaultRequestHeaders.Add(protectedHeader.ProtectedHeaderName, protectedHeaderStringValue);
                    break;
            }
    }

    #endregion

    #region Exceptions

    /// <summary>
    ///     Ошибка о пустом списке заголовков api key.
    /// </summary>
    private readonly ArgumentException _protectedHeadersArgumentException =
        new("Ошибка: Список значений защищенности не может быть пустым.");

    /// <summary>
    ///     Ошибка о конфигурации api key заголовка, которая равна null.
    /// </summary>
    private readonly ArgumentException _protectedHeaderArgumentException =
        new("Ошибка: Значение заголовка не может быть равным 'null'.");

    #endregion
}