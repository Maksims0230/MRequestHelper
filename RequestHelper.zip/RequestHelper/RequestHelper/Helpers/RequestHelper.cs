﻿#nullable disable
using System.Diagnostics.CodeAnalysis;
using RequestHelper.Helpers.Configurations;

namespace RequestHelper.Helpers
{
    public static class RequestHelper
    {
        #region Local Methods

        internal static byte[] ReadAsByteArray(this HttpContent content)
        {
            using var stream = content.ReadAsStream();
            using var memoryStream = new MemoryStream();
            stream.CopyTo(memoryStream);
            memoryStream.Position = 0;
            return memoryStream.ToArray();
        }

        #endregion

        #region Exceptions

        private static readonly ArgumentException ConfigurationsAddException =
            new("Ошибка: Конфигурация с таким именем уже существует.");

        private static readonly ArgumentException ConfigurationsNameException =
            new("Ошибка: Значение имени конфигурации было пустой строкой.");

        internal static readonly InvalidDataException IsConfiguredFalse =
            new("Ошибка: Значение имени конфигурации было пустой строкой.");

        internal static readonly ArgumentException RequestIdAttributeIsNotSet =
            new("Ошибка: Не был установлен атрибут помечающий идентифицирующее поле объекта.");

        internal static readonly ArgumentException RequestListNullOrEmpty =
            new("Ошибка: Список был равен 'null' или количество элементов равно 0.");

        internal static readonly ArgumentException RequestListNull =
            new("Ошибка: Список был равен 'null'.");

        internal static readonly InvalidDataException HttpClientBaseAddressIsNull =
            new("Ошибка: Конфигурация HttpClient не содержит BaseAddress.");

        #endregion

        #region Propreties

        private static Dictionary<string, RequestHelperConfiguration> Configurations { get; set; } = null!;

        internal static bool IsConfigured { get; private set; }

        private static RequestHelperConfiguration _configuration = new();

        public static RequestHelperConfiguration Configuration
        {
            get => _configuration;
            private set
            {
                IsConfigured = true;
                if (!_configuration.Equals(value))
                    _configuration = value;
            }
        }

        #endregion

        #region Configuring Methods

        public static void AddConfiguration(string configurationName,
            RequestHelperConfiguration configuration,
            AddConfigurationMode addMode = AddConfigurationMode.AddingAndSet)
        {
            Configurations ??= new Dictionary<string, RequestHelperConfiguration>();

            switch (addMode)
            {
                case AddConfigurationMode.AddingAndSet:
                    if (string.IsNullOrWhiteSpace(configurationName))
                        throw ConfigurationsNameException;
                    if (!Configurations.TryAdd(configurationName, configuration))
                        throw ConfigurationsAddException;
                    Configuration = Configurations[configurationName];
                    break;
                case AddConfigurationMode.OnlyAdding:
                    if (!Configurations.TryAdd(configurationName, configuration))
                        throw ConfigurationsAddException;
                    break;
                case AddConfigurationMode.OnlySet:
                    Configuration = configuration;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(addMode), addMode,
                        "Ошибка: индекс находился за пределами перечисления 'AddConfigurationMode'.");
            }
        }

        public static void SetConfiguration(string configurationName)
        {
            if (string.IsNullOrWhiteSpace(configurationName))
                throw ConfigurationsNameException;

            if (!Configurations.ContainsKey(configurationName))
                throw new ArgumentOutOfRangeException(nameof(configurationName), configurationName,
                    "Ошибка: Отсутствует конфигурация с данным именем.");

            Configuration = Configurations[configurationName];
        }

        public static void SetConfiguration([NotNull] RequestHelperConfiguration configuration)
        {
            Configuration = configuration;
        }

        #endregion
    }
}