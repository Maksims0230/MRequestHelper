﻿#nullable disable
namespace RequestHelper.Helpers;

/// <summary>
///     Способы добавления конфигурации
/// </summary>
public enum AddConfigurationMode
{
    /// <summary>
    ///     Добавляет в список конфигураций и устанавливает добавленную конфигурацию
    /// </summary>
    AddingAndSet = 0,

    /// <summary>
    ///     Только устанавливает значение конфигурации без добавления в список
    /// </summary>
    OnlySet,

    /// <summary>
    ///     Только добавляет в список конфигураций
    /// </summary>
    OnlyAdding
}