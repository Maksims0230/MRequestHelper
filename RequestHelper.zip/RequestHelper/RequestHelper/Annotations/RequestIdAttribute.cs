﻿using System.Runtime.CompilerServices;

namespace RequestHelper.Annotations;

[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
public class RequestIdAttribute : Attribute
{
    internal readonly string PropertyName;
    public int Order { get; set; } = 0;
    
    public RequestIdAttribute([CallerMemberName] string propertyName = null!)
    {
        PropertyName = propertyName;
    }
}