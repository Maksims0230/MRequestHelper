﻿namespace RequestHelper.Annotations;

[AttributeUsage(AttributeTargets.Class)]
public class RequestPathAttribute : Attribute
{
    public string Path { get; set; }

    public RequestPathAttribute(string path = null!, string? pattern = null)
    {
        Path ??= pattern is null ? $"{path}s" : string.Format(pattern, path);
    }
}