﻿global using System.Text.Json;
global using System.Text.Json.Serialization;
global using System.Reflection;
global using System.Net;